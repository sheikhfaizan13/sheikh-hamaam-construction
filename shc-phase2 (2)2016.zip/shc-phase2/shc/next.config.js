const headers = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
];
module.exports = {
  images: { formats: ["image/avif", "image/webp"] },
  async headers() { return [{ source: "/(.*)", headers }]; },
};
